"""
Part 3: Web Scraping - E-Commerce Analysis
==========================================
Scrapes book data from books.toscrape.com

Submission files produced by running this script:
  - task1_travel_books.csv
  - task1_analysis.txt
  - task2_categories.csv
  - task2_comparison.png
  - task3_books.csv
  - task3_books.xlsx
  - task3_books.json
  - scraper.log
"""

import json
import logging
import os
import time
from datetime import datetime
from urllib.parse import urljoin, urlparse
from urllib.robotparser import RobotFileParser

import matplotlib.pyplot as plt
import pandas as pd
import requests
from bs4 import BeautifulSoup
from openpyxl import load_workbook
from openpyxl.styles import Font

# ── Output folder ──────────────────────────────────────────────────────────────
OUTPUT_DIR = os.path.join("outputs", "part3")
os.makedirs(OUTPUT_DIR, exist_ok=True)

def out(filename):
    """Helper: full path inside the output folder."""
    return os.path.join(OUTPUT_DIR, filename)


# ── Shared helpers ─────────────────────────────────────────────────────────────

RATING_MAP = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}


def can_scrape(url, user_agent="*"):
    """
    Check robots.txt to see if scraping the given URL is allowed.

    Args:
        url:        Full URL to check.
        user_agent: Bot's user-agent string.

    Returns:
        bool: True if allowed, False otherwise.
    """
    try:
        parsed = urlparse(url)
        robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
        rp = RobotFileParser()
        rp.set_url(robots_url)
        rp.read()
        allowed = rp.can_fetch(user_agent, url)
        if allowed:
            print(f"✅ Allowed: {url}")
        else:
            print(f"❌ Blocked by robots.txt: {url}")
        return allowed
    except Exception as e:
        print(f"⚠️  Could not read robots.txt: {e} — proceeding with caution.")
        return True   # assume allowed when robots.txt is unreachable


# ══════════════════════════════════════════════════════════════════════════════
# TASK 1 — Travel Books
# ══════════════════════════════════════════════════════════════════════════════

def scrape_travel_books():
    """
    Scrape ALL pages of the Travel category.

    Requirements:
    - Handle pagination until no next page exists
    - 1-second polite delay between pages
    - Extract: title, price, rating, in_stock, url

    Saves: task1_travel_books.csv
    Returns: DataFrame
    """
    session = requests.Session()
    session.headers.update(
        {"User-Agent": "Mozilla/5.0 (Educational Purpose) TravelBookScraper/1.0"}
    )

    url = "http://books.toscrape.com/catalogue/category/books/travel_2/index.html"
    all_books = []

    while url:
        print(f"Scraping: {url}")
        try:
            response = session.get(url, timeout=10)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, "lxml")

            for article in soup.select("article.product_pod"):
                title_el  = article.select_one("h3 a")
                price_raw = article.select_one(".price_color").text
                avail     = article.select_one(".availability").text.strip()
                rating_el = article.select_one(".star-rating")

                all_books.append({
                    "title":    title_el.get("title", ""),
                    "price":    float(''.join(c for c in price_raw if c.isdigit() or c == '.')),
                    "rating":   RATING_MAP.get(rating_el["class"][1], 0),
                    "in_stock": "In stock" in avail,
                    "url":      urljoin(url, article.select_one("h3 a")["href"]),
                })

            next_link = soup.select_one(".next a")
            url = urljoin(url, next_link["href"]) if next_link else None
            time.sleep(1)

        except Exception as e:
            print(f"Error scraping {url}: {e}")
            break

    df = pd.DataFrame(all_books)
    df.to_csv(out("task1_travel_books.csv"), index=False)
    print(f"✓ Saved task1_travel_books.csv ({len(df)} books)")
    return df


def analyse_travel_books(df):
    """
    Answer the Task 1.2 analysis questions and save to task1_analysis.txt.
    """
    avg_price      = df["price"].mean()
    five_star      = (df["rating"] == 5).sum()
    pct_in_stock   = df["in_stock"].mean() * 100

    with open(out("task1_analysis.txt"), "w") as f:
        f.write("Task 1 — Travel Books Analysis\n")
        f.write("=" * 40 + "\n\n")
        f.write(f"Total travel books scraped : {len(df)}\n")
        f.write(f"Average price              : £{avg_price:.2f}\n")
        f.write(f"Books rated 5 stars        : {five_star}\n")
        f.write(f"Percentage in stock        : {pct_in_stock:.1f}%\n")

    print(f"\nTotal travel books scraped: {len(df)}")
    print(f"Average price: £{avg_price:.2f}")
    print(f"Books with 5-star rating: {five_star}")
    print(f"Percentage in stock: {pct_in_stock:.1f}%")
    print("✓ Saved task1_analysis.txt")


# ══════════════════════════════════════════════════════════════════════════════
# TASK 2 — Multi-Category Comparison
# ══════════════════════════════════════════════════════════════════════════════

class CategoryScraper:
    """Scrape multiple categories and produce a comparative analysis."""

    BASE_URL = "http://books.toscrape.com"

    # FIX: categories list now matches the task requirement exactly
    #      (Fiction, Mystery, Historical Fiction, Science Fiction)
    #      Travel was replaced by Fiction.
    CATEGORIES = {
        "Fiction":            f"{BASE_URL}/catalogue/category/books/fiction_10/index.html",
        "Mystery":            f"{BASE_URL}/catalogue/category/books/mystery_3/index.html",
        "Historical Fiction": f"{BASE_URL}/catalogue/category/books/historical-fiction_4/index.html",
        "Science Fiction":    f"{BASE_URL}/catalogue/category/books/science-fiction_16/index.html",
    }

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update(
            {"User-Agent": "Mozilla/5.0 (Educational Purpose) CategoryScraper/1.0"}
        )

    def scrape_category(self, category_name, max_pages=2):
        """
        Scrape up to `max_pages` pages from a single category.

        Args:
            category_name: Key in self.CATEGORIES dict.
            max_pages:     Page cap (task requires first 2 pages only).

        Returns:
            list of book dicts
        """
        url = self.CATEGORIES.get(category_name)
        if not url:
            print(f"Category '{category_name}' not found.")
            return []

        all_books = []
        pages_done = 0

        while url and pages_done < max_pages:
            print(f"Scraping {category_name} — page {pages_done + 1}: {url}")
            try:
                response = self.session.get(url, timeout=10)
                response.raise_for_status()
                soup = BeautifulSoup(response.text, "lxml")

                for article in soup.select("article.product_pod"):
                    price_raw = article.select_one(".price_color").text
                    rating_el = article.select_one(".star-rating")
                    avail     = article.select_one(".availability").text.strip()

                    all_books.append({
                        "title":    article.select_one("h3 a").get("title", ""),
                        "price":    float(''.join(c for c in price_raw if c.isdigit() or c == '.')),
                        "rating":   RATING_MAP.get(rating_el["class"][1]),
                        "in_stock": "In stock" in avail,
                        "category": category_name,
                        "url":      urljoin(url, article.select_one("h3 a")["href"]),
                    })

                next_link = soup.select_one(".next a")
                url = urljoin(url, next_link["href"]) if next_link else None
                pages_done += 1
                time.sleep(1)

            except Exception as e:
                print(f"Error scraping {url}: {e}")
                break

        return all_books

    def scrape_multiple_categories(self, categories):
        """
        Scrape all given categories and combine into one DataFrame.

        Saves: task2_categories.csv
        Returns: DataFrame
        """
        all_books = []
        for cat in categories:
            all_books.extend(self.scrape_category(cat, max_pages=2))

        df = pd.DataFrame(all_books)
        # FIX: save to correct submission filename in output folder
        df.to_csv(out("task2_categories.csv"), index=False)
        print(f"✓ Saved task2_categories.csv ({len(df)} books across {len(categories)} categories)")
        return df

    def compare_categories(self, df):
        """
        Compute per-category stats and print insights.

        Returns:
            dict of {category: {avg_price, avg_rating, in_stock_percentage}}
        """
        stats = df.groupby("category").agg(
            average_price=("price", "mean"),
            average_rating=("rating", "mean"),
            in_stock_percentage=("in_stock", lambda x: x.mean() * 100),
        )
        print("\nCategory Comparison:")
        print(stats.to_string())

        highest_rated = stats["average_rating"].idxmax()
        most_expensive = stats["average_price"].idxmax()
        print(f"\n💡 Highest average rating : {highest_rated} "
              f"({stats.loc[highest_rated, 'average_rating']:.2f}★)")
        print(f"💡 Most expensive category: {most_expensive} "
              f"(£{stats.loc[most_expensive, 'average_price']:.2f})")

        return stats.to_dict(orient="index")

    def plot_comparison(self, comparison_stats):
        """
        Create side-by-side bar charts comparing avg price and avg rating.

        Saves: task2_comparison.png
        """
        categories  = list(comparison_stats.keys())
        avg_prices  = [comparison_stats[c]["average_price"]  for c in categories]
        avg_ratings = [comparison_stats[c]["average_rating"] for c in categories]
        x = range(len(categories))

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

        ax1.bar(x, avg_prices, color="skyblue", edgecolor="white")
        ax1.set_xlabel("Category")
        ax1.set_ylabel("Average Price (£)")
        ax1.set_title("Average Price by Category")
        ax1.set_xticks(x)
        ax1.set_xticklabels(categories, rotation=30, ha="right")

        ax2.bar(x, avg_ratings, color="lightcoral", edgecolor="white")
        ax2.set_xlabel("Category")
        ax2.set_ylabel("Average Rating (★)")
        ax2.set_title("Average Rating by Category")
        ax2.set_xticks(x)
        ax2.set_xticklabels(categories, rotation=30, ha="right")

        fig.suptitle("Multi-Category Book Comparison", fontsize=14, fontweight="bold")
        fig.tight_layout()
        fig.savefig(out("task2_comparison.png"), dpi=120)
        plt.close(fig)
        print("✓ Saved task2_comparison.png")


# ══════════════════════════════════════════════════════════════════════════════
# TASK 3 — Advanced Scraping Pipeline
# ══════════════════════════════════════════════════════════════════════════════

class AdvancedBookScraper:
    """
    Production-ready book scraper with:
    - Rate limiting    (max 10 requests / minute)
    - Retry logic      (3 attempts, exponential backoff)
    - Logging          (scraper.log)
    - robots.txt check
    - Progress saving / resuming
    - Data validation
    - Multi-format export (CSV, Excel, JSON)
    """

    BASE_URL = "http://books.toscrape.com"

    CATEGORIES = {
        "Mystery":          f"{BASE_URL}/catalogue/category/books/mystery_3/index.html",
        "Science Fiction":  f"{BASE_URL}/catalogue/category/books/science-fiction_16/index.html",
        "Fantasy":          f"{BASE_URL}/catalogue/category/books/fantasy_19/index.html",
    }

    def __init__(self, output_dir=OUTPUT_DIR):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

        # Logging — writes to scraper.log in the output folder
        log_path = os.path.join(output_dir, "scraper.log")
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.INFO)
        # Only add the handler if one isn't already attached (prevents duplicate log lines)
        if not self.logger.handlers:
            fh = logging.FileHandler(log_path)
            fh.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
            self.logger.addHandler(fh)

        # HTTP session
        self.session = requests.Session()
        self.session.headers.update(
            {"User-Agent": "Mozilla/5.0 (Educational Purpose) AdvancedBookScraper/1.0"}
        )

        # FIX: rate limiter now actually implemented (was fully commented out)
        self.request_times: list[float] = []   # rolling window of timestamps

        # Progress tracker: {category: {page_url: 'completed'|'pending'}}
        self.progress: dict = {}

    # ── Rate limiting ──────────────────────────────────────────────────────────

    def _rate_limit(self):
        """
        Enforce max 10 requests per 60-second window.
        Sleeps only when the limit is reached.
        """
        now = time.time()
        # Drop timestamps older than 60 seconds
        self.request_times = [t for t in self.request_times if now - t < 60]

        if len(self.request_times) >= 10:
            # Wait until the oldest request is 60 s old, then add 0.1 s buffer
            wait_for = 60 - (now - self.request_times[0]) + 0.1
            self.logger.info(f"Rate limit reached — sleeping {wait_for:.2f}s")
            time.sleep(wait_for)

        self.request_times.append(time.time())

    # ── robots.txt ─────────────────────────────────────────────────────────────

    def check_robots_txt(self, url):
        """Return True if scraping the URL is allowed by robots.txt."""
        return can_scrape(url, user_agent=self.session.headers["User-Agent"])

    # ── Retry logic ────────────────────────────────────────────────────────────

    def scrape_with_retry(self, url, max_attempts=3):
        """
        GET a URL with exponential backoff (1s → 2s → 4s).

        Returns:
            str: page HTML, or None after all attempts fail.
        """
        for attempt in range(max_attempts):
            try:
                self._rate_limit()
                response = self.session.get(url, timeout=10)
                response.raise_for_status()
                return response.text

            except Exception as e:
                wait_time = 2 ** (attempt + 1)   # 2, 4, 8 seconds
                self.logger.warning(
                    f"Attempt {attempt + 1}/{max_attempts} failed for {url}: {e}. "
                    f"Retrying in {wait_time}s..."
                )
                time.sleep(wait_time)

        self.logger.error(f"All {max_attempts} attempts failed for {url}. Skipping.")
        return None

    # ── Data validation ────────────────────────────────────────────────────────

    def validate_book_data(self, book):
        """
        Validate a single book dict.

        Checks:
        - title is non-empty
        - price is a positive number
        - rating is an integer between 1 and 5

        Returns:
            bool: True if valid
        """
        if not book.get("title"):
            self.logger.warning("Validation failed: missing title")
            return False
        if not isinstance(book.get("price"), (int, float)) or book["price"] <= 0:
            self.logger.warning(f"Validation failed: invalid price {book.get('price')!r}")
            return False
        if book.get("rating") is None:
            self.logger.warning(f"Validation failed: unrecognised rating class for '{book.get('title')}'")
            return False
        if not isinstance(book.get("rating"), int) or not (1 <= book["rating"] <= 5):
            self.logger.warning(f"Validation failed: invalid rating {book.get('rating')!r}")
            return False
        return True

    # ── Progress persistence ───────────────────────────────────────────────────

    def save_progress(self, books, filename="progress.json"):
        """Persist current book list to disk so scraping can be resumed."""
        path = os.path.join(self.output_dir, filename)
        try:
            with open(path, "w") as f:
                json.dump(books, f, indent=2)
            self.logger.info(f"Progress saved to {path} ({len(books)} books)")
        except Exception as e:
            self.logger.error(f"Failed to save progress: {e}")

    def load_progress(self, filename="progress.json"):
        """Load previously saved progress. Returns empty list if none found."""
        path = os.path.join(self.output_dir, filename)
        try:
            with open(path) as f:
                books = json.load(f)
            self.logger.info(f"Loaded {len(books)} books from previous run")
            return books
        except FileNotFoundError:
            self.logger.info("No previous progress found — starting fresh.")
            return []
        except Exception as e:
            self.logger.error(f"Failed to load progress: {e}")
            return []

    # ── Category scraper ───────────────────────────────────────────────────────

    def scrape_category(self, category_name, max_pages=5):
        """
        Scrape one category (up to `max_pages` pages) using retry + rate limiting.

        Returns:
            list of validated book dicts
        """
        url = self.CATEGORIES.get(category_name)
        if not url:
            self.logger.error(f"Unknown category: {category_name}")
            return []

        self.progress.setdefault(category_name, {})
        books = []
        pages_done = 0

        while url and pages_done < max_pages:
            self.logger.info(f"Scraping {category_name} — page {pages_done + 1}: {url}")
            self.progress[category_name][url] = "pending"

            html = self.scrape_with_retry(url)
            if html is None:
                self.progress[category_name][url] = "failed"
                break

            soup = BeautifulSoup(html, "lxml")

            for article in soup.select("article.product_pod"):
                try:
                    price_raw = article.select_one(".price_color").text
                    rating_el = article.select_one(".star-rating")
                    avail     = article.select_one(".availability").text.strip()

                    book = {
                        "title":    article.select_one("h3 a").get("title", ""),
                        "price":    float(''.join(c for c in price_raw if c.isdigit() or c == '.')),
                        "rating":   RATING_MAP.get(rating_el["class"][1]),
                        "in_stock": "In stock" in avail,
                        "category": category_name,
                        "url":      urljoin(url, article.select_one("h3 a")["href"]),
                    }
                    if self.validate_book_data(book):
                        books.append(book)

                except Exception as e:
                    self.logger.warning(f"Skipping malformed article: {e}")

            self.progress[category_name][url] = "completed"
            next_link = soup.select_one(".next a")
            url = urljoin(url, next_link["href"]) if next_link else None
            pages_done += 1

        return books

    # ── Multi-format export ────────────────────────────────────────────────────

    def export_data(self, books, base_filename="task3_books"):
        """
        Export book list to CSV, Excel (bold headers), and JSON.

        Saves:
            task3_books.csv
            task3_books.xlsx
            task3_books.json
        """
        if not books:
            self.logger.warning("No books to export.")
            return

        df = pd.DataFrame(books)

        # CSV — UTF-8 encoded
        csv_path = os.path.join(self.output_dir, f"{base_filename}.csv")
        df.to_csv(csv_path, index=False, encoding="utf-8")
        self.logger.info(f"Exported CSV → {csv_path}")

        # Excel — bold headers, auto column width
        xlsx_path = os.path.join(self.output_dir, f"{base_filename}.xlsx")
        df.to_excel(xlsx_path, index=False)
        wb = load_workbook(xlsx_path)
        ws = wb.active
        for cell in ws[1]:
            cell.font = Font(bold=True)
        for col in ws.columns:
            max_len = max((len(str(c.value)) for c in col if c.value), default=10)
            ws.column_dimensions[col[0].column_letter].width = max_len + 2
        wb.save(xlsx_path)
        self.logger.info(f"Exported Excel → {xlsx_path}")

        # JSON — properly structured
        json_path = os.path.join(self.output_dir, f"{base_filename}.json")
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "generated_at": datetime.now().isoformat(),
                    "total_books":  len(books),
                    "books":        books,
                },
                f,
                indent=2,
                ensure_ascii=False,
            )
        self.logger.info(f"Exported JSON → {json_path}")
        print(f"✓ Exported {len(books)} books to CSV, Excel, and JSON")

    # ── Full pipeline ──────────────────────────────────────────────────────────

    def run_full_pipeline(self, categories, max_pages_per_category=5):
        """
        Complete end-to-end pipeline:
          1. Check robots.txt
          2. Load any previous progress
          3. Scrape each category with validation
          4. Save progress after each category
          5. Deduplicate by URL
          6. Export to all formats
        """
        # 1. robots.txt guard
        if not self.check_robots_txt(self.BASE_URL):
            self.logger.error("robots.txt disallows scraping. Aborting.")
            return

        # 2. Load previous progress
        all_books = self.load_progress()
        scraped_urls = {b["url"] for b in all_books}

        # 3 + 4. Scrape and save after each category
        for category in categories:
            self.logger.info(f"=== Starting category: {category} ===")
            new_books = self.scrape_category(category, max_pages=max_pages_per_category)

            # Avoid duplicates when resuming
            for book in new_books:
                if book["url"] not in scraped_urls:
                    all_books.append(book)
                    scraped_urls.add(book["url"])

            self.save_progress(all_books)
            print(f"  {category}: {len(new_books)} books scraped")

        # 5. Final deduplication (safety net)
        seen = set()
        unique_books = []
        for b in all_books:
            if b["url"] not in seen:
                unique_books.append(b)
                seen.add(b["url"])

        # 6. Export
        self.export_data(unique_books)
        self.logger.info(
            f"Pipeline complete. {len(unique_books)} unique books collected."
        )
        print(f"\n✅ Pipeline complete — {len(unique_books)} unique books collected.")


# ══════════════════════════════════════════════════════════════════════════════
# Main runner
# ══════════════════════════════════════════════════════════════════════════════

def main():
    print("=" * 60)
    print("  Part 3 — Web Scraping: E-Commerce Analysis")
    print("=" * 60)

    # ── Task 1 ─────────────────────────────────────────────────────────────────
    print("\n[Task 1] Scraping Travel books...")
    travel_df = scrape_travel_books()
    analyse_travel_books(travel_df)

    # ── Task 2 ─────────────────────────────────────────────────────────────────
    print("\n[Task 2] Scraping Fiction, Mystery, Historical Fiction, Science Fiction...")
    cat_scraper = CategoryScraper()
    books_df = cat_scraper.scrape_multiple_categories(
        ["Fiction", "Mystery", "Historical Fiction", "Science Fiction"]
    )
    comparison_stats = cat_scraper.compare_categories(books_df)
    cat_scraper.plot_comparison(comparison_stats)

    # ── Task 3 ─────────────────────────────────────────────────────────────────
    print("\n[Task 3] Running advanced scraping pipeline...")
    adv_scraper = AdvancedBookScraper()
    adv_scraper.run_full_pipeline(
        categories=["Mystery", "Science Fiction", "Fantasy"],
        max_pages_per_category=3,
    )

    print("\n✅ All tasks complete. Output files:")
    for fname in [
        "task1_travel_books.csv",
        "task1_analysis.txt",
        "task2_categories.csv",
        "task2_comparison.png",
        "task3_books.csv",
        "task3_books.xlsx",
        "task3_books.json",
        "scraper.log",
    ]:
        path = out(fname)
        exists = "✓" if os.path.exists(path) else "✗ MISSING"
        print(f"  {exists}  {path}")


if __name__ == "__main__":
    main()