"""
Part 4 Final Project: Book Market Intelligence System
======================================================
Integrates data from:
  1. SQLite database  (library.db — from Part 1)
  2. REST API         (GitHub API — book-related repositories)
  3. Web scraping     (books.toscrape.com)

Deliverables produced by running this script:
  - market_intelligence.db
  - exports/api_data.csv
  - exports/scraped_data.csv
  - exports/pipeline_logs.csv
  - exports/library_books.csv
  - analysis.html
  - pipeline.log
  - README.md
"""

# ── Standard library ──────────────────────────────────────────────────────────
import sqlite3
import logging
import json
import os
import time
from datetime import datetime

# ── Third-party ───────────────────────────────────────────────────────────────
import requests
from bs4 import BeautifulSoup
import pandas as pd
import matplotlib
matplotlib.use("Agg")          # non-interactive backend (no display needed)
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns

# ── Output folder ─────────────────────────────────────────────────────────────
EXPORT_DIR = "exports"
os.makedirs(EXPORT_DIR, exist_ok=True)


# ══════════════════════════════════════════════════════════════════════════════
# DataCollectionPipeline
# ══════════════════════════════════════════════════════════════════════════════

class DataCollectionPipeline:
    """
    Unified data collection from multiple sources.
    Integrates: SQLite databases, REST APIs, and Web Scraping.
    """

    # ── Init ──────────────────────────────────────────────────────────────────

    def __init__(self, db_path="market_intelligence.db"):
        """
        Initialize pipeline: logging, DB connection, table creation.

        Args:
            db_path (str): Path to the pipeline's own SQLite database.
        """
        # Logging: file + console, using dedicated handlers (avoids basicConfig
        # issues when the module is imported after logging is already configured)
        self.logger = logging.getLogger("DataCollectionPipeline")
        self.logger.setLevel(logging.INFO)
        if not self.logger.handlers:
            fmt = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
            fh = logging.FileHandler("pipeline.log")
            fh.setFormatter(fmt)
            sh = logging.StreamHandler()
            sh.setFormatter(fmt)
            self.logger.addHandler(fh)
            self.logger.addHandler(sh)

        # Database
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self._create_tables()

        # HTTP session (reuses TCP connections for efficiency)
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "DataPipeline/1.0 (Educational)"})

        self.logger.info("Pipeline initialized → %s", db_path)

    # ── Table creation ────────────────────────────────────────────────────────

    def _create_tables(self):
        """Create all pipeline tables if they don't already exist."""
        cursor = self.conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS api_data (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                source       TEXT NOT NULL,
                data_type    TEXT NOT NULL,
                content      TEXT NOT NULL,
                collected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS scraped_data (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                url        TEXT NOT NULL,
                title      TEXT,
                content    TEXT,
                scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS pipeline_logs (
                id                INTEGER PRIMARY KEY AUTOINCREMENT,
                source_type       TEXT NOT NULL,
                records_collected INTEGER,
                status            TEXT,
                error_message     TEXT,
                timestamp         TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Library books table — stores results from the DB source
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS library_books (
                book_id          INTEGER PRIMARY KEY,
                title            TEXT,
                author           TEXT,
                genre            TEXT,
                publication_year INTEGER,
                copies_available INTEGER,
                borrow_count     INTEGER DEFAULT 0,
                collected_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        self.conn.commit()

    # ── Database collection ───────────────────────────────────────────────────

    def collect_from_database(self, query, source_db_path):
        """
        Run a SQL query against another SQLite database.

        Args:
            query (str):          SQL SELECT query.
            source_db_path (str): Path to the source .db file.

        Returns:
            pd.DataFrame: Query results, or empty DataFrame on error.
        """
        self.logger.info("Collecting from database: %s", source_db_path)
        try:
            source_conn = sqlite3.connect(source_db_path)
            df = pd.read_sql_query(query, source_conn)
            source_conn.close()

            # Persist to local library_books table (upsert by book_id)
            if not df.empty and "book_id" in df.columns:
                cursor = self.conn.cursor()
                for _, row in df.iterrows():
                    cursor.execute("""
                        INSERT OR REPLACE INTO library_books
                            (book_id, title, author, genre, publication_year,
                             copies_available, borrow_count)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (
                        row.get("book_id"),
                        row.get("title"),
                        row.get("author_name", row.get("name", "")),
                        row.get("genre"),
                        row.get("publication_year"),
                        row.get("copies_available"),
                        row.get("borrow_count", 0),
                    ))
                self.conn.commit()

            self.logger.info("✓ Collected %d records from database", len(df))
            self._log_collection("database", len(df), "success")
            return df

        except Exception as e:
            self.logger.error("✗ Database error: %s", e)
            self._log_collection("database", 0, "error", str(e))
            return pd.DataFrame()

    # ── API collection ────────────────────────────────────────────────────────

    def collect_from_api(self, url, params=None):
        """
        Fetch JSON from a REST API endpoint and store raw response.

        Args:
            url (str):     Full API endpoint URL.
            params (dict): Optional query parameters.

        Returns:
            dict | list | None: Parsed JSON, or None on error.
        """
        self.logger.info("Collecting from API: %s", url)
        try:
            response = self.session.get(url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()

            cursor = self.conn.cursor()
            cursor.execute(
                "INSERT INTO api_data (source, data_type, content) VALUES (?, ?, ?)",
                (url, "json", json.dumps(data)),
            )
            self.conn.commit()

            self.logger.info("✓ Collected API data from %s", url)
            self._log_collection("api", 1, "success")
            return data

        except Exception as e:
            self.logger.error("✗ API error: %s", e)
            self._log_collection("api", 0, "error", str(e))
            return None

    # ── Web scraping ──────────────────────────────────────────────────────────

    def collect_from_web(self, url, selectors):
        """
        Scrape structured data from a webpage using CSS selectors.

        Args:
            url (str):        Page URL to scrape.
            selectors (dict): {field_name: css_selector} mapping.

        Returns:
            dict: {field: scraped_text}, values None if selector not found.
        """
        self.logger.info("Scraping: %s", url)
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, "lxml")

            data = {}
            for field, selector in selectors.items():
                element = soup.select_one(selector)
                data[field] = element.get_text(strip=True) if element else None

            cursor = self.conn.cursor()
            cursor.execute(
                "INSERT INTO scraped_data (url, title, content) VALUES (?, ?, ?)",
                (url, data.get("title"), json.dumps(data)),
            )
            self.conn.commit()

            self.logger.info("✓ Scraped data from %s", url)
            self._log_collection("web", 1, "success")
            return data

        except Exception as e:
            self.logger.error("✗ Scraping error: %s", e)
            self._log_collection("web", 0, "error", str(e))
            return {}

    def scrape_catalogue_page(self, url):
        """
        Scrape a full books.toscrape.com catalogue page (20 books).

        Returns:
            tuple: (list of book dicts, next_page_url | None)
        """
        RATING_MAP = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}
        books = []
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, "lxml")

            for article in soup.select("article.product_pod"):
                price_raw = article.select_one(".price_color").text
                rating_el = article.select_one(".star-rating")
                avail     = article.select_one(".availability").text.strip()

                book = {
                    "title":    article.select_one("h3 a").get("title", ""),
                    # Robust price parsing — strips any currency encoding variant
                    "price":    float("".join(c for c in price_raw if c.isdigit() or c == ".")),
                    "rating":   RATING_MAP.get(rating_el["class"][1]),
                    "in_stock": "In stock" in avail,
                    "url":      requests.compat.urljoin(url, article.select_one("h3 a")["href"]),
                }
                books.append(book)

            next_link = soup.select_one(".next a")
            next_url = requests.compat.urljoin(url, next_link["href"]) if next_link else None
            return books, next_url

        except Exception as e:
            self.logger.error("✗ Catalogue scrape error: %s", e)
            return [], None

    # ── Utility methods ───────────────────────────────────────────────────────

    def _log_collection(self, source_type, records, status, error_msg=None):
        """Write a collection event to pipeline_logs."""
        cursor = self.conn.cursor()
        cursor.execute(
            """INSERT INTO pipeline_logs
               (source_type, records_collected, status, error_message)
               VALUES (?, ?, ?, ?)""",
            (source_type, records, status, error_msg),
        )
        self.conn.commit()

    def get_collection_stats(self):
        """
        Summarize all data collection activity.

        Returns:
            dict with keys: api_records, scraped_records, logs (DataFrame)
        """
        stats = {}
        cursor = self.conn.cursor()

        cursor.execute("SELECT COUNT(*) FROM api_data")
        stats["api_records"] = cursor.fetchone()[0]

        cursor.execute("SELECT COUNT(*) FROM scraped_data")
        stats["scraped_records"] = cursor.fetchone()[0]

        stats["logs"] = pd.read_sql_query(
            """SELECT source_type,
                      COUNT(*) AS total_attempts,
                      SUM(CASE WHEN status='success' THEN 1 ELSE 0 END) AS successful
               FROM pipeline_logs
               GROUP BY source_type""",
            self.conn,
        )
        return stats

    def export_all_data(self, output_dir=EXPORT_DIR):
        """Export all pipeline tables to CSV files."""
        os.makedirs(output_dir, exist_ok=True)

        tables = {
            "api_data":      "api_data.csv",
            "scraped_data":  "scraped_data.csv",
            "pipeline_logs": "pipeline_logs.csv",
            "library_books": "library_books.csv",
        }
        for table, filename in tables.items():
            df = pd.read_sql_query(f"SELECT * FROM {table}", self.conn)
            df.to_csv(os.path.join(output_dir, filename), index=False)

        self.logger.info("✓ All data exported to %s/", output_dir)

    def close(self):
        """Close the SQLite database connection."""
        self.conn.close()
        self.logger.info("Pipeline closed")


# ══════════════════════════════════════════════════════════════════════════════
# Market Intelligence Analysis
# ══════════════════════════════════════════════════════════════════════════════

class MarketIntelligenceAnalyzer:
    """
    Generate market insights and visualizations from collected data.
    Produces analysis.html with embedded charts.
    """

    def __init__(self, pipeline_db="market_intelligence.db",
                 library_db="library.db"):
        self.pipeline_conn = sqlite3.connect(pipeline_db)
        self.library_conn  = sqlite3.connect(library_db)
        self.charts = []        # list of (filename, caption) for HTML report
        os.makedirs(EXPORT_DIR, exist_ok=True)

    # ── Data loaders ──────────────────────────────────────────────────────────

    def _library_books(self):
        return pd.read_sql_query("""
            SELECT b.book_id, b.title, b.genre, b.publication_year,
                   b.copies_available, a.name AS author,
                   COUNT(br.borrow_id) AS borrow_count
            FROM books b
            JOIN authors a ON b.author_id = a.author_id
            LEFT JOIN borrowings br ON b.book_id = br.book_id
            GROUP BY b.book_id
        """, self.library_conn)

    def _scraped_books(self):
        raw = pd.read_sql_query("SELECT content FROM scraped_data", self.pipeline_conn)
        rows = []
        for _, r in raw.iterrows():
            try:
                rows.append(json.loads(r["content"]))
            except Exception:
                pass
        return pd.DataFrame(rows) if rows else pd.DataFrame()

    def _github_repos(self):
        raw = pd.read_sql_query("SELECT content FROM api_data", self.pipeline_conn)
        rows = []
        for _, r in raw.iterrows():
            try:
                data = json.loads(r["content"])
                items = data.get("items", [data]) if isinstance(data, dict) else data
                for item in (items if isinstance(items, list) else [items]):
                    if isinstance(item, dict) and "full_name" in item:
                        rows.append({
                            "name":        item.get("full_name", ""),
                            "stars":       item.get("stargazers_count", 0),
                            "forks":       item.get("forks_count", 0),
                            "language":    item.get("language", "Unknown"),
                            "description": item.get("description", ""),
                            "topics":      ", ".join(item.get("topics", [])),
                        })
            except Exception:
                pass
        return pd.DataFrame(rows) if rows else pd.DataFrame()

    # ── Chart helpers ─────────────────────────────────────────────────────────

    def _save_chart(self, fig, filename, caption):
        path = os.path.join(EXPORT_DIR, filename)
        fig.savefig(path, dpi=120, bbox_inches="tight")
        plt.close(fig)
        self.charts.append((filename, caption))
        return path

    # ── Individual charts ─────────────────────────────────────────────────────

    def chart_genre_distribution(self, df):
        """Bar chart: number of books per genre."""
        counts = df["genre"].value_counts()
        fig, ax = plt.subplots(figsize=(8, 5))
        bars = ax.bar(counts.index, counts.values,
                      color=sns.color_palette("pastel"), edgecolor="white")
        ax.bar_label(bars)
        ax.set_title("Book Count by Genre", fontsize=14, fontweight="bold")
        ax.set_xlabel("Genre")
        ax.set_ylabel("Number of Books")
        fig.tight_layout()
        self._save_chart(fig, "chart1_genre_distribution.png",
                         "Figure 1 — Book Count by Genre (Library DB)")

    def chart_publication_timeline(self, df):
        """Line chart: books published per decade."""
        df = df.copy()
        df["decade"] = (df["publication_year"] // 10) * 10
        counts = df.groupby("decade").size()
        fig, ax = plt.subplots(figsize=(9, 5))
        ax.plot(counts.index, counts.values, marker="o", linewidth=2,
                color="#4C72B0", markersize=8)
        ax.fill_between(counts.index, counts.values, alpha=0.15, color="#4C72B0")
        ax.set_title("Books Published per Decade", fontsize=14, fontweight="bold")
        ax.set_xlabel("Decade")
        ax.set_ylabel("Number of Books")
        ax.set_xticks(counts.index)
        fig.tight_layout()
        self._save_chart(fig, "chart2_publication_timeline.png",
                         "Figure 2 — Publication Timeline by Decade")

    def chart_author_productivity(self, df):
        """Horizontal bar: books per author."""
        counts = df["author"].value_counts()
        fig, ax = plt.subplots(figsize=(9, 5))
        bars = ax.barh(counts.index, counts.values,
                       color=sns.color_palette("muted"), edgecolor="white")
        ax.bar_label(bars, padding=3)
        ax.set_title("Books per Author", fontsize=14, fontweight="bold")
        ax.set_xlabel("Number of Books")
        ax.invert_yaxis()
        fig.tight_layout()
        self._save_chart(fig, "chart3_author_productivity.png",
                         "Figure 3 — Author Productivity (Library DB)")

    def chart_copies_by_genre(self, df):
        """Grouped bar: total copies available per genre."""
        grouped = df.groupby("genre")["copies_available"].sum().sort_values(ascending=False)
        fig, ax = plt.subplots(figsize=(8, 5))
        bars = ax.bar(grouped.index, grouped.values,
                      color=sns.color_palette("Set2"), edgecolor="white")
        ax.bar_label(bars)
        ax.set_title("Total Copies Available by Genre", fontsize=14, fontweight="bold")
        ax.set_xlabel("Genre")
        ax.set_ylabel("Total Copies")
        fig.tight_layout()
        self._save_chart(fig, "chart4_copies_by_genre.png",
                         "Figure 4 — Inventory (Copies Available) by Genre")

    def chart_borrow_frequency(self, df):
        """Bar chart: borrow count per book (top 10)."""
        top = df.nlargest(10, "borrow_count")[["title", "borrow_count"]]
        fig, ax = plt.subplots(figsize=(10, 5))
        bars = ax.bar(range(len(top)), top["borrow_count"].values,
                      color=sns.color_palette("rocket", len(top)), edgecolor="white")
        ax.bar_label(bars)
        ax.set_xticks(range(len(top)))
        ax.set_xticklabels(
            [t[:25] + "…" if len(t) > 25 else t for t in top["title"]],
            rotation=30, ha="right"
        )
        ax.set_title("Top 10 Most Borrowed Books", fontsize=14, fontweight="bold")
        ax.set_ylabel("Borrow Count")
        fig.tight_layout()
        self._save_chart(fig, "chart5_borrow_frequency.png",
                         "Figure 5 — Top 10 Most Borrowed Books")

    def chart_scraped_price_distribution(self, df):
        """Histogram: price distribution of scraped books."""
        if df.empty or "price" not in df.columns:
            return
        prices = pd.to_numeric(df["price"].astype(str).str.replace("[^0-9.]", "", regex=True),
                                errors="coerce").dropna()
        if prices.empty:
            return
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.hist(prices, bins=20, color="#55A868", edgecolor="white")
        ax.axvline(prices.mean(), color="red", linestyle="--",
                   label=f"Mean £{prices.mean():.2f}")
        ax.set_title("Price Distribution (books.toscrape.com)", fontsize=14, fontweight="bold")
        ax.set_xlabel("Price (£)")
        ax.set_ylabel("Number of Books")
        ax.legend()
        fig.tight_layout()
        self._save_chart(fig, "chart6_price_distribution.png",
                         "Figure 6 — Scraped Book Price Distribution")

    def chart_scraped_rating_distribution(self, df):
        """Bar chart: star rating breakdown of scraped books."""
        if df.empty or "rating" not in df.columns:
            return
        counts = df["rating"].value_counts().sort_index()
        labels = [f"{int(r)}★" for r in counts.index]
        fig, ax = plt.subplots(figsize=(7, 5))
        bars = ax.bar(labels, counts.values,
                      color=sns.color_palette("YlOrRd", len(counts)), edgecolor="white")
        ax.bar_label(bars)
        ax.set_title("Rating Distribution (books.toscrape.com)", fontsize=14, fontweight="bold")
        ax.set_xlabel("Star Rating")
        ax.set_ylabel("Number of Books")
        fig.tight_layout()
        self._save_chart(fig, "chart7_rating_distribution.png",
                         "Figure 7 — Scraped Book Rating Distribution")

    def chart_github_languages(self, df):
        """Pie chart: programming language breakdown of GitHub repos."""
        if df.empty or "language" not in df.columns:
            return
        counts = df["language"].value_counts().head(6)
        fig, ax = plt.subplots(figsize=(7, 6))
        wedges, texts, autotexts = ax.pie(
            counts.values, labels=counts.index, autopct="%1.1f%%",
            colors=sns.color_palette("tab10"), startangle=140
        )
        ax.set_title("GitHub Book Repos by Language", fontsize=14, fontweight="bold")
        fig.tight_layout()
        self._save_chart(fig, "chart8_github_languages.png",
                         "Figure 8 — GitHub Book-Related Repos by Language")

    # ── Insight generation ────────────────────────────────────────────────────

    def generate_insights(self, lib_df, scraped_df, github_df):
        """Compute key market insights as a dict of plain-text findings."""
        insights = {}

        # Library insights
        if not lib_df.empty:
            insights["total_library_books"]  = len(lib_df)
            insights["dominant_genre"]       = lib_df["genre"].value_counts().idxmax()
            insights["most_prolific_author"] = lib_df["author"].value_counts().idxmax()
            insights["most_borrowed_book"]   = lib_df.loc[lib_df["borrow_count"].idxmax(), "title"]
            insights["avg_copies"]           = round(lib_df["copies_available"].mean(), 1)
            insights["total_copies"]         = int(lib_df["copies_available"].sum())

        # Scraped web data insights
        if not scraped_df.empty and "price" in scraped_df.columns:
            prices = pd.to_numeric(
                scraped_df["price"].astype(str).str.replace("[^0-9.]", "", regex=True),
                errors="coerce"
            ).dropna()
            if not prices.empty:
                insights["avg_web_price"]  = round(float(prices.mean()), 2)
                insights["min_web_price"]  = round(float(prices.min()), 2)
                insights["max_web_price"]  = round(float(prices.max()), 2)

        if not scraped_df.empty and "rating" in scraped_df.columns:
            avg_r = pd.to_numeric(scraped_df["rating"], errors="coerce").mean()
            if pd.notna(avg_r):
                insights["avg_web_rating"] = round(float(avg_r), 2)

        # GitHub insights
        if not github_df.empty:
            insights["total_github_repos"] = len(github_df)
            insights["top_github_repo"]    = (
                github_df.loc[github_df["stars"].idxmax(), "name"]
                if "stars" in github_df.columns else "N/A"
            )
            insights["top_language"] = (
                github_df["language"].value_counts().idxmax()
                if "language" in github_df.columns else "N/A"
            )

        return insights

    # ── HTML report ───────────────────────────────────────────────────────────

    def build_html_report(self, insights, stats, lib_df, scraped_df, github_df):
        """Write analysis.html with charts, stats table, and insights."""

        # ── Build charts ──────────────────────────────────────────────────────
        if not lib_df.empty:
            self.chart_genre_distribution(lib_df)
            self.chart_publication_timeline(lib_df)
            self.chart_author_productivity(lib_df)
            self.chart_copies_by_genre(lib_df)
            self.chart_borrow_frequency(lib_df)

        if not scraped_df.empty:
            self.chart_scraped_price_distribution(scraped_df)
            self.chart_scraped_rating_distribution(scraped_df)

        if not github_df.empty:
            self.chart_github_languages(github_df)

        # ── Helpers ───────────────────────────────────────────────────────────
        def fmt(val, prefix="", suffix=""):
            return f"{prefix}{val}{suffix}" if val is not None else "N/A"

        def chart_grid():
            html = '<div class="chart-grid">'
            for fname, caption in self.charts:
                rel_path = os.path.join(EXPORT_DIR, fname)
                html += f"""
                <figure>
                  <img src="{rel_path}" alt="{caption}">
                  <figcaption>{caption}</figcaption>
                </figure>"""
            html += "</div>"
            return html

        def stats_table():
            if stats["logs"].empty:
                return "<p>No log data available.</p>"
            rows = ""
            for _, row in stats["logs"].iterrows():
                rows += f"""<tr>
                  <td>{row['source_type'].title()}</td>
                  <td>{int(row['total_attempts'])}</td>
                  <td>{int(row['successful'])}</td>
                  <td>{'✅' if row['total_attempts'] == row['successful'] else '⚠️'}</td>
                </tr>"""
            return f"""
            <table>
              <thead><tr>
                <th>Source</th><th>Attempts</th><th>Successful</th><th>Status</th>
              </tr></thead>
              <tbody>{rows}</tbody>
            </table>"""

        def lib_table():
            if lib_df.empty:
                return "<p>No library data collected.</p>"
            rows = ""
            for _, r in lib_df.iterrows():
                rows += f"""<tr>
                  <td>{r.get('title','')}</td>
                  <td>{r.get('author','')}</td>
                  <td>{r.get('genre','')}</td>
                  <td>{r.get('publication_year','')}</td>
                  <td>{r.get('copies_available','')}</td>
                  <td>{r.get('borrow_count', 0)}</td>
                </tr>"""
            return f"""
            <table>
              <thead><tr>
                <th>Title</th><th>Author</th><th>Genre</th>
                <th>Year</th><th>Copies</th><th>Borrows</th>
              </tr></thead>
              <tbody>{rows}</tbody>
            </table>"""

        # ── Render HTML ───────────────────────────────────────────────────────
        now = datetime.now().strftime("%B %d, %Y %H:%M")

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Book Market Intelligence Report</title>
  <style>
    *, *::before, *::after {{ box-sizing: border-box; }}
    body {{
      font-family: 'Segoe UI', Arial, sans-serif;
      margin: 0; background: #f5f7fa; color: #2c3e50;
    }}
    header {{
      background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
      color: white; padding: 40px 60px;
    }}
    header h1 {{ margin: 0 0 8px; font-size: 2rem; }}
    header p  {{ margin: 0; opacity: .7; font-size: .95rem; }}
    main {{ max-width: 1100px; margin: 40px auto; padding: 0 30px; }}
    section {{ background: white; border-radius: 12px; padding: 32px;
               margin-bottom: 30px; box-shadow: 0 2px 12px rgba(0,0,0,.07); }}
    h2 {{ margin-top: 0; font-size: 1.4rem; color: #0f3460;
          border-bottom: 2px solid #e8eaf0; padding-bottom: 10px; }}
    h3 {{ color: #16213e; }}
    .kpi-grid {{ display: grid; grid-template-columns: repeat(auto-fill,minmax(180px,1fr));
                 gap: 16px; margin-top: 16px; }}
    .kpi {{ background: #f0f4ff; border-radius: 10px; padding: 18px 20px;
            text-align: center; }}
    .kpi .value {{ font-size: 2rem; font-weight: 700; color: #0f3460; }}
    .kpi .label {{ font-size: .8rem; color: #666; margin-top: 4px; }}
    table {{ width: 100%; border-collapse: collapse; font-size: .9rem; }}
    th    {{ background: #0f3460; color: white; padding: 10px 14px; text-align: left; }}
    td    {{ padding: 9px 14px; border-bottom: 1px solid #eee; }}
    tr:hover td {{ background: #f8f9ff; }}
    .chart-grid {{ display: grid;
                   grid-template-columns: repeat(auto-fill, minmax(480px, 1fr));
                   gap: 24px; margin-top: 16px; }}
    figure {{ margin: 0; background: #fafafa; border-radius: 10px;
              overflow: hidden; border: 1px solid #e8eaf0; }}
    figure img {{ width: 100%; display: block; }}
    figcaption {{ padding: 10px 14px; font-size: .82rem; color: #555;
                  border-top: 1px solid #e8eaf0; }}
    .insight-list {{ list-style: none; padding: 0; margin: 0; }}
    .insight-list li {{
      padding: 10px 14px 10px 40px; margin-bottom: 8px;
      background: #f8f9ff; border-radius: 8px; position: relative;
      border-left: 4px solid #0f3460;
    }}
    .insight-list li::before {{ content: "💡"; position: absolute; left: 12px; }}
    footer {{ text-align: center; padding: 30px; color: #999; font-size: .85rem; }}
  </style>
</head>
<body>

<header>
  <h1>📚 Book Market Intelligence Report</h1>
  <p>Generated: {now} &nbsp;|&nbsp; Sources: Library DB · GitHub API · Web Scraping</p>
</header>

<main>

  <!-- Executive Summary ---------------------------------------------------- -->
  <section>
    <h2>Executive Summary</h2>
    <p>
      This report synthesizes book market data collected from three independent sources:
      a local library SQLite database, the GitHub REST API (book-related repositories),
      and the <em>books.toscrape.com</em> catalogue. Together they provide a 360° view
      of reading trends, inventory health, pricing, and technology adoption in the book
      ecosystem.
    </p>
    <div class="kpi-grid">
      <div class="kpi">
        <div class="value">{insights.get('total_library_books', 'N/A')}</div>
        <div class="label">Library Books</div>
      </div>
      <div class="kpi">
        <div class="value">{insights.get('total_copies', 'N/A')}</div>
        <div class="label">Total Copies</div>
      </div>
      <div class="kpi">
        <div class="value">{fmt(insights.get('avg_web_price'), prefix='£')}</div>
        <div class="label">Avg Web Price</div>
      </div>
      <div class="kpi">
        <div class="value">{fmt(insights.get('avg_web_rating'), suffix='★')}</div>
        <div class="label">Avg Web Rating</div>
      </div>
      <div class="kpi">
        <div class="value">{insights.get('total_github_repos', 'N/A')}</div>
        <div class="label">GitHub Repos</div>
      </div>
      <div class="kpi">
        <div class="value">{stats['api_records'] + stats['scraped_records']}</div>
        <div class="label">Records Collected</div>
      </div>
    </div>
  </section>

  <!-- Pipeline Stats ------------------------------------------------------- -->
  <section>
    <h2>Data Collection Statistics</h2>
    {stats_table()}
  </section>

  <!-- Library Data ---------------------------------------------------------- -->
  <section>
    <h2>🗄️ Source 1 — Library Database</h2>
    <p>
      Data retrieved from <code>library.db</code> via SQL query joining
      <em>books</em>, <em>authors</em>, and <em>borrowings</em> tables.
    </p>
    {lib_table()}
  </section>

  <!-- Visualizations -------------------------------------------------------- -->
  <section>
    <h2>📊 Visualizations</h2>
    {chart_grid()}
  </section>

  <!-- Market Insights ------------------------------------------------------- -->
  <section>
    <h2>💡 Market Insights</h2>

    <h3>Popular Genres</h3>
    <ul class="insight-list">
      <li>The dominant genre in the library collection is
          <strong>{insights.get('dominant_genre', 'N/A')}</strong>,
          reflecting strong local reader preference for this category.</li>
      <li>Genre-level inventory data reveals where acquisition budgets should be
          prioritised to meet demand.</li>
    </ul>

    <h3>Price Trends</h3>
    <ul class="insight-list">
      <li>Online book prices (books.toscrape.com) range from
          <strong>£{insights.get('min_web_price', 'N/A')}</strong> to
          <strong>£{insights.get('max_web_price', 'N/A')}</strong>,
          with an average of
          <strong>£{insights.get('avg_web_price', 'N/A')}</strong>.</li>
      <li>Price distribution is broadly spread, suggesting a diverse market
          catering to both budget-conscious and premium readers.</li>
    </ul>

    <h3>Rating Patterns</h3>
    <ul class="insight-list">
      <li>The average web catalogue rating is
          <strong>{insights.get('avg_web_rating', 'N/A')}★</strong>,
          indicating overall positive quality perception across listed titles.</li>
      <li>The most borrowed library book is
          <strong>"{insights.get('most_borrowed_book', 'N/A')}"</strong>,
          suggesting strong community engagement with this title.</li>
    </ul>

    <h3>Technology Trends (GitHub)</h3>
    <ul class="insight-list">
      <li>The most popular programming language among book-related GitHub repos
          is <strong>{insights.get('top_language', 'N/A')}</strong>,
          indicating the technology stack favoured by developers building
          book tools and libraries.</li>
      <li>The top-starred repository is
          <strong>{insights.get('top_github_repo', 'N/A')}</strong>,
          signalling strong community interest in this project.</li>
    </ul>

    <h3>Recommendations</h3>
    <ul class="insight-list">
      <li>Increase acquisition of
          <strong>{insights.get('dominant_genre', 'N/A')}</strong> titles —
          the genre is both the most represented and most borrowed.</li>
      <li>Monitor online pricing benchmarks (avg £{insights.get('avg_web_price','N/A')})
          when setting library acquisition budgets.</li>
      <li>Most prolific author in the collection is
          <strong>{insights.get('most_prolific_author', 'N/A')}</strong> —
          consider featuring their works in reading programmes.</li>
      <li>Track GitHub repository activity in
          <strong>{insights.get('top_language', 'N/A')}</strong> for emerging
          library management tooling opportunities.</li>
    </ul>
  </section>

</main>

<footer>
  Book Market Intelligence System &nbsp;|&nbsp; Part 4 Final Project &nbsp;|&nbsp; {now}
</footer>

</body>
</html>"""

        with open("analysis.html", "w", encoding="utf-8") as f:
            f.write(html)
        print("✓ Saved analysis.html")

    def close(self):
        self.pipeline_conn.close()
        self.library_conn.close()


# ══════════════════════════════════════════════════════════════════════════════
# README
# ══════════════════════════════════════════════════════════════════════════════

README = """# Book Market Intelligence System

## Overview
A production-style data pipeline that collects book-market data from three
independent sources and generates a consolidated market intelligence report.

## Requirements
```
pip install requests beautifulsoup4 lxml pandas matplotlib seaborn openpyxl
```

## Files
| File | Description |
|------|-------------|
| `final_project.py` | Main pipeline script (this file) |
| `library.db` | Source library database (from Part 1) |
| `market_intelligence.db` | Pipeline output database |
| `analysis.html` | Interactive HTML analysis report |
| `pipeline.log` | Full operation log |
| `exports/` | CSV exports of all tables |

## How to Run
```bash
python final_project.py
```
> Requires internet access for GitHub API and books.toscrape.com steps.

## Architecture

```
┌─────────────────────────────────────────────────────┐
│              DataCollectionPipeline                  │
│                                                      │
│  ┌──────────────┐  ┌───────────────┐  ┌──────────┐  │
│  │  library.db  │  │  GitHub API   │  │  Web     │  │
│  │  (SQLite)    │  │  /search/     │  │  Scraper │  │
│  └──────┬───────┘  └──────┬────────┘  └────┬─────┘  │
│         │                 │                │         │
│         ▼                 ▼                ▼         │
│  ┌─────────────────────────────────────────────┐     │
│  │         market_intelligence.db              │     │
│  │  library_books | api_data | scraped_data    │     │
│  │               | pipeline_logs               │     │
│  └─────────────────────────────────────────────┘     │
│                          │                           │
│              MarketIntelligenceAnalyzer              │
│                          │                           │
│               ┌──────────┴──────────┐                │
│               ▼                     ▼                │
│         analysis.html          exports/*.csv         │
└─────────────────────────────────────────────────────┘
```

## Data Schema

### library_books
| Column | Type | Description |
|--------|------|-------------|
| book_id | INTEGER PK | Original book ID |
| title | TEXT | Book title |
| author | TEXT | Author name |
| genre | TEXT | Genre |
| publication_year | INTEGER | Year published |
| copies_available | INTEGER | Copies in library |
| borrow_count | INTEGER | Total borrows |

### api_data
| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER PK | Auto ID |
| source | TEXT | API endpoint URL |
| data_type | TEXT | e.g. 'json' |
| content | TEXT | JSON-serialized response |
| collected_at | TIMESTAMP | Collection time |

### scraped_data
| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER PK | Auto ID |
| url | TEXT | Page URL |
| title | TEXT | Page title |
| content | TEXT | JSON-encoded fields |
| scraped_at | TIMESTAMP | Scrape time |

### pipeline_logs
| Column | Type | Description |
|--------|------|-------------|
| id | INTEGER PK | Auto ID |
| source_type | TEXT | 'database' / 'api' / 'web' |
| records_collected | INTEGER | Records in this run |
| status | TEXT | 'success' or 'error' |
| error_message | TEXT | Error detail (NULL on success) |

## Ethical Notes
- Always check `robots.txt` before scraping
- Respect API rate limits (GitHub: 60 unauthenticated req/hr)
- Use polite delays between requests
"""


# ══════════════════════════════════════════════════════════════════════════════
# Main
# ══════════════════════════════════════════════════════════════════════════════

def main():
    print("=" * 60)
    print("  Book Market Intelligence System — Part 4")
    print("=" * 60)

    # ── Initialize pipeline ───────────────────────────────────────────────────
    pipeline = DataCollectionPipeline(db_path="market_intelligence.db")

    # ── Source 1: Library database ────────────────────────────────────────────
    print("\n[1/3] Collecting from library.db ...")
    library_df = pipeline.collect_from_database(
        """
        SELECT b.book_id, b.title, b.genre, b.publication_year,
               b.copies_available, a.name AS author_name,
               COUNT(br.borrow_id) AS borrow_count
        FROM books b
        JOIN authors a ON b.author_id = a.author_id
        LEFT JOIN borrowings br ON b.book_id = br.book_id
        GROUP BY b.book_id
        """,
        "library.db",
    )
    print(f"   → {len(library_df)} books collected")

    # ── Source 2: GitHub API ──────────────────────────────────────────────────
    print("\n[2/3] Collecting from GitHub API ...")
    github_endpoints = [
        ("https://api.github.com/search/repositories",
         {"q": "books library python", "sort": "stars", "per_page": 10}),
        ("https://api.github.com/search/repositories",
         {"q": "book recommendation machine-learning", "sort": "stars", "per_page": 10}),
    ]
    github_results = []
    for url, params in github_endpoints:
        result = pipeline.collect_from_api(url, params=params)
        if result:
            github_results.append(result)
        time.sleep(1)   # polite delay — GitHub rate-limits unauthenticated requests
    print(f"   → {len(github_results)} API responses collected")

    # ── Source 3: Web scraping ────────────────────────────────────────────────
    print("\n[3/3] Scraping books.toscrape.com ...")
    scraped_books = []
    url = "http://books.toscrape.com/catalogue/page-1.html"
    pages_scraped = 0
    max_pages = 3   # scrape first 3 pages (60 books) — respectful limit

    while url and pages_scraped < max_pages:
        books, url = pipeline.scrape_catalogue_page(url)
        scraped_books.extend(books)
        pages_scraped += 1
        print(f"   Page {pages_scraped}: {len(books)} books")
        time.sleep(1)   # polite 1-second delay

    # Also scrape a single book detail page to demonstrate collect_from_web
    pipeline.collect_from_web(
        "http://books.toscrape.com/catalogue/a-light-in-the-attic_1000/index.html",
        {
            "title":        "h1",
            "price":        ".price_color",
            "availability": ".availability",
            "description":  "#product_description ~ p",
        },
    )
    print(f"   → {len(scraped_books)} books scraped total")

    # Persist scraped catalogue books to scraped_data table
    if scraped_books:
        cursor = pipeline.conn.cursor()
        for book in scraped_books:
            cursor.execute(
                "INSERT INTO scraped_data (url, title, content) VALUES (?, ?, ?)",
                (book["url"], book["title"], json.dumps(book)),
            )
        pipeline.conn.commit()
        pipeline._log_collection("web", len(scraped_books), "success")

    # ── Stats & export ────────────────────────────────────────────────────────
    stats = pipeline.get_collection_stats()
    print("\n=== Collection Statistics ===")
    print(f"API Records    : {stats['api_records']}")
    print(f"Scraped Records: {stats['scraped_records']}")
    print("\nLogs by Source:")
    print(stats["logs"].to_string(index=False))

    pipeline.export_all_data()
    pipeline.close()

    # ── Analysis & report ─────────────────────────────────────────────────────
    print("\n[Analysis] Building market intelligence report ...")
    analyzer = MarketIntelligenceAnalyzer(
        pipeline_db="market_intelligence.db",
        library_db="library.db",
    )

    lib_df     = analyzer._library_books()
    scraped_df = pd.DataFrame(scraped_books) if scraped_books else pd.DataFrame()
    github_df  = analyzer._github_repos()

    insights = analyzer.generate_insights(lib_df, scraped_df, github_df)
    analyzer.build_html_report(insights, stats, lib_df, scraped_df, github_df)
    analyzer.close()

    # ── README ────────────────────────────────────────────────────────────────
    with open("README.md", "w", encoding="utf-8") as f:
        f.write(README)
    print("✓ Saved README.md")

    # ── Summary ───────────────────────────────────────────────────────────────
    print("\n✅ All deliverables ready:")
    for path in [
        "final_project.py", "market_intelligence.db", "analysis.html",
        "pipeline.log", "README.md",
        f"{EXPORT_DIR}/api_data.csv", f"{EXPORT_DIR}/scraped_data.csv",
        f"{EXPORT_DIR}/pipeline_logs.csv", f"{EXPORT_DIR}/library_books.csv",
    ]:
        mark = "✓" if os.path.exists(path) else "✗ MISSING"
        print(f"  {mark}  {path}")


if __name__ == "__main__":
    main()